using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoomOfFortune : RoomBase
{
    private void OnTriggerEnter(Collider otherObject)
    {
       
    }
    private void OnTriggerStay(Collider otherObject)
    {
        
    }
    private void OnTriggerExit(Collider otherObject)
    {
        
    }
}
